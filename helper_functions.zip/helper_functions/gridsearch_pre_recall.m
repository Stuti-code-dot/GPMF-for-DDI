clear all
addpath(genpath('helper_functions'));
addpath(genpath('matrix_completion'));
addpath(genpath('..\Dependencies')); 

%-------------------------------------------------------------------

diary off; diary on;
fprintf('\nSTART TIME:    %s\n\n', datestr(now));

%-------------------------------------------------------------------

global predictionMethod gridSearchMode

global k k1 k2 k3 k4 pp  mu1 mu2 mu gama sigma scale_param;    
global num_iter p lambda_U lambda_V lambda_U1 lambda_U3 lambda_U4;  

gridSearchMode = 0;   % grid search mode?
% if turned on:
% - suppresses printing of intermediate fold results on screen
% - prevents saving of prediction scores

warning off

%-------------------------------------------------------------------

global m n Sd Sv ds; 

% The location of the folder that contains the data
% load('C:/Users/ABC/Desktop/FOURTH_SEMESTER/GPMF_updated/data_processed/virus_drug_association_first.mat')
% load('C:/Users/ABC/Desktop/FOURTH_SEMESTER/GPMF_updated/data_processed/first_drug_sim_matrix.mat')
% load('C:/Users/ABC/Desktop/FOURTH_SEMESTER/GPMF_updated/data_processed/vir_sim_matrix_first.mat')
% load('C:/Users/ABC/Desktop/FOURTH_SEMESTER/GPMF_updated/data_processed/drugs_moa_sim.mat')
% load('C:/Users/ABC/Desktop/FOURTH_SEMESTER/GPMF_updated/data_processed/virus_symptoms_sim_second_cos.mat')
% load('C:/Users/ABC/Desktop/FOURTH_SEMESTER/GPMF_updated/data_processed/RnaDna/drug_sim_matrix.mat')
% load('C:/Users/ABC/Desktop/FOURTH_SEMESTER/GPMF_updated/data_processed/RnaDna/vir_sim_matrix.mat')
% load('C:/Users/ABC/Desktop/FOURTH_SEMESTER/GPMF_updated/data_processed/RnaDna/virus_drug_association.mat')

load('C:/Users/ABC/Desktop/FOURTH_SEMESTER/GPMF_updated/data_processed/first_drug_sim_matrix.mat')
load('C:/Users/ABC/Desktop/FOURTH_SEMESTER/GPMF_updated/data_processed/drugs_moa_sim.mat')
Sd = Sd1+Sd2;
lst_month = {'RefSeq', 'Jan_20','Feb_20','Mar_20','Apr_20','May_20','Jun_20','Jul_20','Aug_20','Sep_20','Oct_20','Nov_20','Dec_20','Jan_21','Feb_21','Mar_21','Apr_21','May_21'};
for num_month=1:18
month = string(lst_month(1))
load('C:/Users/ABC/Desktop/FOURTH_SEMESTER/GPMF_updated/data_processed/data_processed_new/vir_sim_matrix_updated_sv_' +month+ '.mat')
load('C:/Users/ABC/Desktop/FOURTH_SEMESTER/GPMF_updated/data_processed/data_processed_new/virus_drug_association_' +month+ '.mat')

% Sd = Sd1+Sd2;
% Sv = Sv1+Sv2;

% St = Sv;

mat=mat'; %size of data matrix: #drugsx#vir
Y=mat; 
size(Y);
n = 10;% 'n' in "n-fold experiment"

% the different datasets
% datasets={'e','ic','gpcr','nr'}%,'movielens_100k','metabolic'};


% CV parameters
m = 1;  % number of n-fold experiments (repetitions)
n = 10; % the 'n' in "n-fold experiment"
%-------------------------------------------------------------------

disp(['gridSearchMode = ' num2str(gridSearchMode)])
disp(' ')

diary off; diary on;

%*********************************************************************
global num_iter k lambda_l  lambda_t p sigma  eta rs lambda_U lambda_V lambda_U1 lambda_U3 lambda_U4
%*********************************************************************

%-------------------------------------------------------------------
%-------------------------------------------------------------------
disp(' ')
disp('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
% disp('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
% disp('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
disp(' ')
%-------------------------------------------------------------------
%-------------------------------------------------------------------


predictionMethod ='GPMF_2layer';% 'dgrdmf';

global k k1 k2 k3 k4 pp outsweep gama sigma scale_param ;
% cvs=1:3
for cvs=2%1:3%:3%:3
    disp('==============================================================');
    disp(['Prediction method = ' predictionMethod])
    cv_setting1 = ['S' int2str(cvs)];
    cv_setting = [2];
    switch cv_setting1
    case 'S1', disp('CV Setting Used: S1 - PAIR');
               cv_setting = 1;
    case 'S2', disp('CV Setting Used: S2 - TARGET');
    %              case 'S2', disp('CV Setting Used: S2 - DRUG');
               cv_setting = 2;
    case 'S3', disp('CV Setting Used: S3 - DRUG');
    %             case 'S3', disp('CV Setting Used: S3 - TARGET');
               cv_setting = 3;
    end
    disp(' ')

% for cvs=4%1:3%:3%:3
%     disp('==============================================================');
%     disp(['Prediction method = ' predictionMethod])
%     cv_setting1 = ['S' int2str(cvs)];
%     cv_setting = [4];
%     switch cv_setting1
%     case 'S4', disp('LOOCV');
%                cv_setting = 4;
%     end
%     disp(' ')


    % run chosen selection method and output CV results
    for ds=[2]
        diary off; diary on;
        disp('--------------------------------------------------------------');

        bestrecall = -Inf;
        bestprec=   -Inf;
        bestf1 = -Inf;
       
        for pp=[2] % 5 7]% 5   ]%  2 ]%]12 2 5]
            for outsweep=[10]
                for k1= [24,20,16]% 20  ]
                    for k2= [16,12,8,4]
%                         for k3= [8,4]
                            for mu = [0.001,0.005,0.01,0.05,0.1,0.5]
                                for sigma=[0.01,0.1,0.5,1]%0.1 1 5    ]% 5 1 15   ]  %1
                                    for gama=[0.01,0.1,0.5,1]%  0.01 0.5 1 10 100 1000   ]%[1.5 0.5 5 10]%45
                                        for lambda_U1 = [0.01,0.1,1]
                                            for lambda_U3 = [0.01,0.1,1]
                                                for scale_param =[0.01,0.001]%20 10 5 ]%10-9 for nr %30-20 n20-20 for gpcr
        %                                                 [auc,aupr,y3] = get_CV_results_setting4(Y,n,cv_setting,predictionMethod);
                                                    [auc,aupr,pre,rec,f1] = get_CV_results(Y,n,cv_setting,predictionMethod);
        %                                             [ FinalavgPre,FinalavgRec,FinalavgF1 ] = precision_recall_calc(Y,n,cv_setting,predictionMethod,knum);
                                                    if round(bestrecall,4) < round(rec,4)
                                                        bestrecall = rec ;
                                                        bestpre = pre;
                                                        bestf1 = f1;
                                                        bestcomb = [pp,outsweep,mu,k1,k2,sigma,gama,lambda_U1,lambda_U3,scale_param];
                                                        save(['best_params_gpmf2layer_prerecall_S2' + month + '.mat'],'bestcomb','bestrecall','bestpre','bestf1')
                                                    end
                                                    if round(bestrecall,4) == round(rec,4)
                                                        if bestpre < pre
                                                            bestrecall = rec ;
                                                            bestpre = pre;
                                                            bestf1 = f1;
                                                            bestcomb = [pp,outsweep,mu,k1,k2,sigma,gama,lambda_U1,lambda_U3,scale_param];
                                                            save(['best_params_gpmf2layer_prerecall_S2' + month + '.mat'],'bestcomb','bestrecall','bestpre','bestf1')
                                                        end
                                                    end
                                                end
                                            end 
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            end
%         end
%     end
% end
        %end

        disp('Best parameters:')
        ds;
        cvs;
        save(['best_params_gpmf2layer_prerecall_final_S2' + month + '.mat'],'bestcomb','bestrecall','bestpre','bestf1')
        disp(['pp = ' num2str(bestcomb(1))])
        disp(['outsweep = ' num2str(bestcomb(2))])
        disp(['mu = ' num2str(bestcomb(3))]) %mu,k,sigma,gama,lambda_U, lambda_V,scale_param
        disp(['k1 = ' num2str(bestcomb(4))])
        disp(['k2 = ' num2str(bestcomb(5))])
%         disp(['k3 = ' num2str(bestcomb(6))])
        disp(['sigma = ' num2str(bestcomb(6))])
        disp(['gama = ' num2str(bestcomb(7))])
        disp(['lambda_U1 = ' num2str(bestcomb(8))])
        disp(['lambda_U3= ' num2str(bestcomb(9))])
        disp(['scale_param = ' num2str(bestcomb(10))])


        disp('--------------------------------------------------------------');
    end
    disp('==============================================================');
end
end

diary off;