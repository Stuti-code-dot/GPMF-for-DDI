clear all
addpath(genpath('helper_functions'));
addpath(genpath('matrix_completion'));
addpath(genpath('..\Dependencies')); 


%-------------------------------------------------------------------

diary off; diary on;
fprintf('\nSTART TIME:    %s\n\n', datestr(now));

%-------------------------------------------------------------------

global predictionMethod gridSearchMode

%global k  pp lambda_U lambda_r sigma scale_param theta1;   

%global num_iter p lambda_U lambda_V lambda_U1 lambda_U3 lambda_U4;  


gridSearchMode = 0;   % grid search mode?
% if turned on:
% - suppresses printing of intermediate fold results on screen
% - prevents saving of prediction scores

warning off

%-------------------------------------------------------------------

global n Sd ds; 

% The location of the folder that contains the data
%load('C:/Users/Stuti/Desktop/FOURTH_SEMESTER/GPMF_updated/data_processed/virus_drug_association_first.mat')
%load('C:/Users/Stuti/Desktop/FOURTH_SEMESTER/GPMF_updated/data_processed/first_drug_sim_matrix.mat')
%load('C:/Users/Stuti/Desktop/FOURTH_SEMESTER/GPMF_updated/data_processed/vir_sim_matrix_first.mat')
%load('C:/Users/Stuti/Desktop/FOURTH_SEMESTER/GPMF_updated/data_processed/drugs_moa_sim.mat')
%load('C:/Users/Stuti/Desktop/FOURTH_SEMESTER/GPMF_updated/data_processed/virus_symptoms_sim_second_cos.mat')
% load('C:/Users/Stuti/Desktop/FOURTH_SEMESTER/GPMF_updated/data_processed/RnaDna/drug_sim_matrix.mat')
% load('C:/Users/Stuti/Desktop/FOURTH_SEMESTER/GPMF_updated/data_processed/RnaDna/vir_sim_matrix.mat')
% load('C:/Users/Stuti/Desktop/FOURTH_SEMESTER/GPMF_updated/data_processed/RnaDna/virus_drug_association.mat')
%Sd = Sd1+Sd2;
%Sv = Sv1+Sv2;

% St = Sv;

%mat=mat'; %size of data matrix: #drugsx#vir
%Y=mat; 

Y = xlsread('Drug_Interaction_Set2.xlsx');
Sd = xlsread('Drug_Similarity_Set2.xlsx');
size(Y);
n = 1;% 10 'n' in "n-fold experiment"

% the different datasets
% datasets={'e','ic','gpcr','nr'}%,'movielens_100k','metabolic'};


% CV parameters
%m = 1;  % number of n-fold experiments (repetitions)
%n = 10; % the 'n' in "n-fold experiment"
%-------------------------------------------------------------------

disp(['gridSearchMode = ' num2str(gridSearchMode)])
disp(' ')

diary off; diary on;

%*********************************************************************
%global k  pp lambda_U lambda_r sigma scale_param theta1
%global num_iter k lambda_l  lambda_t p sigma  eta rs lambda_U lambda_V lambda_U1 lambda_U3 lambda_U4
%*********************************************************************

%-------------------------------------------------------------------
%-------------------------------------------------------------------
disp(' ')
disp('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
% disp('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
% disp('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
disp(' ')
%-------------------------------------------------------------------
%-------------------------------------------------------------------


predictionMethod ='GPMF_1layer';% 'dgrdmf';
cv_setting =1;
global k  pp lambda_U lambda_r sigma scale_param theta1;  
% cvs=1:3
% for cvs=1:3%1:3%:3%:3
%     disp('==============================================================');
%     disp(['Prediction method = ' predictionMethod])
%     cv_setting1 = ['S' int2str(cvs)];
%     cv_setting =1;% [1 2 3];
%     switch cv_setting1
%     case 'S1', disp('CV Setting Used: S1 - PAIR');
%                cv_setting = 1;
%     case 'S2', disp('CV Setting Used: S2 - TARGET');
%     %              case 'S2', disp('CV Setting Used: S2 - DRUG');
%                cv_setting = 2;
%     case 'S3', disp('CV Setting Used: S3 - DRUG');
%     %             case 'S3', disp('CV Setting Used: S3 - TARGET');
%                cv_setting = 3;
%     end
%     disp(' ')


    % run chosen selection method and output CV results
    for ds=[2]
        diary off; diary on;
        disp('--------------------------------------------------------------');

        bestaupr = -Inf;
        bestauc=   -Inf;
       
        for pp=[2,5]% 5   ]%  2 ]%]12 2 5]
            for k= [100,50,20,10]% 20  ]
                for theta1= [1,0.1,0.01] % 20  ]
                    for sigma=[0.001,0.01,0.1,1]%0.1 1 5    ]% 5 1 15   ]  %1
                        for lambda_U = [0.01,0.1,0.5,1]
                            for lambda_r = [0.01,0.1,0.5,1]
                                for scale_param =[0.001,0.01,0.1]%20 10 5 ]%10-9 for nr %30-20 n20-20 for gpcr
                                    [auc,aupr,pre,rec,f1,acc ]=get_CV_results(Y,n,cv_setting,predictionMethod  );
                                         
                                     if round(bestaupr,4) < round(aupr,4)
                                         bestaupr = aupr ;
                                         bestauc = auc;
                                         bestcomb = [pp,k,theta1,sigma,lambda_U,lambda_r,scale_param];
                                         save(['best_params_gpmf1layer_v3.mat'],'bestcomb','bestaupr','bestauc')
                                     end
                                     if round(bestaupr,4) == round(aupr,4)
                                        if bestauc < auc
                                           bestaupr = aupr ;
                                           bestauc = auc;
                                           bestcomb = [pp,k,theta1,sigma,lambda_U,lambda_r,scale_param];
                                           save(['best_params_gpmf1layer_v3.mat'],'bestcomb','bestaupr','bestauc')
                                        end
                                     end
                                end
                             end 
                         end
                     end
                 end
            end
         end
%                   end
%               end
%            end
%        end
%     end
% end
        %end


        disp('Best parameters:')
        ds;
        cvs;
        save(['best_params_bigdata_gpmf1layer_v2.mat'],'be                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       stcomb','bestaupr','bestauc')
        disp(['pp = ' num2str(bestcomb(1))]) %mu,k,sigma,gama,lambda_U, lambda_V,scale_param
        disp(['k = ' num2str(bestcomb(2))])
        disp(['theta1 = ' num2str(bestcomb(3))])
        disp(['sigma = ' num2str(bestcomb(4))])
        disp(['lambda_U = ' num2str(bestcomb(5))])
        disp(['lambda_r = ' num2str(bestcomb(6))])
        disp(['scale_param = ' num2str(bestcomb(7))])


        disp('--------------------------------------------------------------');
    end
    disp('==============================================================');
% end

diary off;