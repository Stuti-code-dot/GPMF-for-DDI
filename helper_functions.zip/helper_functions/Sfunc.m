function [S] = Sfunc(C,tau) % L_mu == mu

S = sign(C)*max(0,abs(C)-tau);
% S = sign(C)*max(0,(abs(C-tau)));
% S = real(S);
end

