
function [R_est] = PMF_1layer_latest(y,Sd,M,sizeR,rankr,sigma, lambda_U,lambda_r,scale_param, theta1)%mu,k,sigma,gama,lambda_U, lambda_V,scale_param
Ad = Sd;
arr = zeros(10,1);
%initialize factors
R_tr=reshape( M(y,2) ,sizeR);
R=R_tr;
B = R_tr;
% STEP 1: SVD DECOMPOSITION
[F,S,T]=svd(R);
U = F(:,1:rankr);
[n, k] = size(U);
[k, n] = size(U');
t = 0;
outsweep=10;
% STEP 2 : INITIALIZATION
X = scale_param*eye(n,n); 
A = (B/sigma^2 + lambda_r*ones(size(B)));
sigma_U = 0.15;
    
for out = 1:outsweep
    out;

    U_k=U; 

    %Update of X using PCG (Pre-conditioned Conjugate Gradient)
    b = ((B.*R)/sigma^2 + lambda_r*U_k*U_k');
    b_vec = b(:);
 
    %X_upt = pcg(A_vec,b_vec); % Solves for Ax = b
    X_upt = pcg(@(x)reshape(A.*reshape(x,n,n),length(b_vec),1),b_vec);
    X = reshape(X_upt, size(X));

    %%epsilon = (norm(X - U_k*U_k',"fro"))/ norm(X,"fro");
    
    %Update of U using Non-linear Conjugate Gradient Method
    g = @(U) (0.5/sigma_U^2)*(norm(U, "fro")^2) + (lambda_r/2)*(norm(X - U*U',"fro")^2); % g()
    del_g = @(U) (U/sigma_U^2) + lambda_r*(2*(U*U'*U) - (X'+ X)*U); % delta g()
    del_g_old = del_g(U_k); % delta g(U)
    D_k = -1*del_g_old; 
    
    t2 = 2;
    for out2 = 1:t2
        try
        that = fmincon(@(t)g(U_k + t*D_k), 1, [], []);
        catch
               fprintf('!')
        end
        U = U_k + that*D_k; % new U = Uk+(tk*Dk)
    
        del_g_new = del_g(U); % new delta g(U)
    
        beta = ((norm(del_g_new,"fro"))^2)/ ((norm(del_g_old, "fro"))^2);
    
        D_k = -del_g_new + beta*D_k;
        U_k = U;

    end

    U = U_k;
% X = X - diag(diag(X));
% CF = 1/(2*sigma^2)*(norm(R_tr - B.*X,"fro")^2) + 0.5*trace(U'*Gamma_U*U) + (lambda_r/2)*(norm(X - U*U',"fro")^2) - 0.5*log(det(Gamma_U))+  lambda_U*sum(sum(e_U_bar*abs(Gamma_U))) - lambda_U*(sum(sum(e_U*(log(abs(Gamma_U)+del1))))) + lambda_U/2*(norm(Gamma_U, 'fro')^2) ;
a1 =1/(2*sigma^2)*(norm(R_tr - B.*X,"fro")^2);
a2 = (lambda_r/2)*(norm(X - U*U',"fro")^2);
a3 = (0.5/sigma_U^2)*(norm(U, "fro")^2);
CF =a1+a2+a3;
% CF =a3;
arr(out) = CF;
R_est = U*U';
R_est = R_est - diag(diag(R_est));
R_est(R_est>1.0)=1.0;
R_est(R_est<0.0)=0.0;

% R_est = dlarray(R_est);
% R_est = sigmoid(R_est);
% R_est = extractdata(R_est);

% X_est = X;
% X_est = X_est - diag(diag(X_est));
% X_est = dlarray(X_est);
% X_est = sigmoid(X_est);
% X_est = extractdata(X_est);

% R_est
end
figure(1)
plot(real(arr))
ylabel('Loss Function')
xlabel('Iterations')
hFig =figure(1);
set(hFig, 'Position', [100 100 500*1 250*1])
end
