%**************************************************************************
function [R_est] = GPMF_1layer_june_20(y,Sd,M,Mo,sizeR,rankr,sigma, lambda_U,lambda_r,scale_param, theta1)%mu,k,sigma,gama,lambda_U, lambda_V,scale_param
Ad = Sd;
% At = Sv;
arr = zeros(10,1);
%initialize factors
R_tr = reshape( M(y,2) ,sizeR);
R=R_tr;
B = Mo;
% STEP 1: SVD DECOMPOSITION
[F,S,T]=svd(R);
U = F(:,1:rankr);
[n, k] = size(U);
[k, n] = size(U');
t = 0;
outsweep=10;
% STEP 2 : INITIALIZATION
e_U = 0.0*eye(n,n);
del1 = scale_param;
e_U_bar = 0.0*eye(n,n);
Gamma_U = scale_param*eye(n,n);
X = scale_param*eye(n,n); 
A = (B/sigma^2 + lambda_r*ones(size(B)));

% Laplacian Matrices    
Dd = diag(sum(Ad)); 
Lr = Dd - Ad;  
if(det(Dd)==0)
    Dd=0.1*eye(size(Dd))+Dd;
end
L_U = (Dd^(-0.5))*Lr*(Dd^(-0.5));

% Gamma_U = L_U + gama*eye(n,n); 

for i=1:n
        for j=1:n
%              if i~=j
                if Ad(i,j) > 0 
                    e_U(i,j) = 1;
                end

                if Ad(i,j) <= 0
                    e_U_bar(i,j) = 1;
                end
%              end
        end
end
    
for out = 1:outsweep
    out;

    U_k=U; 
    Gamma_U_k = Gamma_U;

    %update of X
    
    
    b = ((B.*R)/sigma^2 + lambda_r*(U_k*U_k')); % introduced the bracket for U_k*U_k' to ensure result is Hermitian
    b_vec = b(:);
 
    %X_upt = pcg(A_vec,b_vec);
    X_upt = pcg(@(x)reshape(A.*reshape(x,n,n),length(b_vec),1),b_vec);
    X = reshape(X_upt, size(X));

    %%epsilon = (norm(X - U_k*U_k',"fro"))/ norm(X,"fro");
    %updqte of U
    g = @(U) 0.5*trace(U'*Gamma_U*U) + (lambda_r/2)*(norm(X - U*U',"fro")^2);
    del_g = @(U) Gamma_U*U + lambda_r*(2*(U*U'*U) - (X'+ X)*U);
    del_g_old = del_g(U_k);
    D_k = -1*del_g_old;
    
    t2 = 2;
    for out2 = 1:t2
        try
        that = fmincon(@(t)g(U_k + t*D_k), 1, [], []);
        catch
               fprintf('!')
        end
        U = U_k + that*D_k;
    
        del_g_new = del_g(U);
    
        beta = ((norm(del_g_new,"fro"))^2)/ ((norm(del_g_old, "fro"))^2);
    
        D_k = -del_g_new + beta*D_k;
        U_k = U;

    end

    U = U_k;
    % STEP 4
    
    % STEP 5
    %f_gamma = trace(U*U'*Gamma_U_k) + Lfunc;
    t1 = 5;%5;
    for out2 = 1:t1
%%         Gamma_U_tilda = Gamma_U_k - theta1*(U*U' - inv(Gamma_U_k)); % changed to enable the loop

        Gamma_U_tilda = Gamma_U - theta1*(U*U' - inv(Gamma_U)); % modified Kriti
    
        idx1 = e_U_bar == 1;
        Gamma_U(idx1) = Sfunc_vec(inv(1+2*lambda_U*theta1)*Gamma_U_tilda(idx1),inv(1+2*lambda_U*theta1));
        
        idx2 = e_U == 1;
        Gamma_U(idx2) = prox_minuslogsum_vec((1/(1+2*lambda_U*theta1)).*Gamma_U_tilda(idx2),2*theta1*lambda_U/(1+2*lambda_U*theta1),del1);
    end

% CF = 1/(2*sigma^2)*(norm(R_tr - B.*X,"fro")^2) + 0.5*trace(U'*Gamma_U*U) + (lambda_r/2)*(norm(X - U*U',"fro")^2) - 0.5*log(det(Gamma_U))+  lambda_U*sum(sum(e_U_bar*abs(Gamma_U))) - lambda_U*(sum(sum(e_U*(log(abs(Gamma_U)+del1))))) + lambda_U/2*(norm(Gamma_U, 'fro')^2) ;
a1 =1/(2*sigma^2)*(norm(R_tr - B.*X,"fro")^2);
a2 = 0.5*trace(U'*Gamma_U*U);
a3 = (lambda_r/2)*(norm(X - U*U',"fro")^2);
a4 =  - 0.5*logdet(Gamma_U); % logdet function to avoid overflow/underflow
a5 = lambda_U*sum(sum(e_U_bar*abs(Gamma_U)));
a6 =  - lambda_U*(sum(sum(e_U*(log(abs(Gamma_U)+del1)))));
a7 = lambda_U/2*(norm(Gamma_U, 'fro')^2);
CF =a1+a2+a3+real(a4)+a5+a6+a7;
arr(out) = CF;

R_est = U*U';
R_est = R_est - diag(diag(R_est));

% Post processing 
% R_est(R_est>1.0)=1.0; % Clipped version
% R_est(R_est<0.0)=0.0;

% %Sigmoid - %% Giving more False Positives
% R_est = dlarray(R_est);
% R_est = sigmoid(R_est);
% R_est = extractdata(R_est);

% X_est = X;
% X_est = X_est - diag(diag(X_est));
% X_est = dlarray(X_est);
% X_est = sigmoid(X_est);
% X_est = extractdata(X_est);

% R_est
end
figure(1)
plot(real(arr))
ylabel('Loss Function')
xlabel('Iterations')
hFig =figure(1);
set(hFig, 'Position', [100 100 500*1 250*1])
end
