%% Author: Kriti, June 2022
%**************************************************************************
function [ wtPre,wtRec,wtF1, Acc ] = precision_recall_mod(labels,predictionScores)
wtPre=0;wtRec=0;wtF1=0; % weighted metrics
Acc =0; % Overall accuracy
p1=0;r1=0; f11=0; % Metrics for class 1
p0=0;r0=0; f10=0; % Metrics for class 0
s0=0; % Support for class 0
s1=0; % Support for class 1

ypred=predictionScores;
ypred(abs(ypred)>=0.5)=1;
ypred(abs(ypred)<0.5)=0;

ytrue = labels;
       
[c,cm,ind,per] = confusion((ytrue)',(ypred)'); 
s0 = sum(cm(1,:));
s1 = sum(cm(2,:));
r1 = cm(2,2)/(cm(2,2)+cm(2,1)); r1(isnan(r1))=0;
p1 = cm(2,2)/(cm(2,2)+cm(1,2)); p1(isnan(p1))=0;
f11 = (2*r1*p1)/(r1+p1); f11(isnan(f11))=0;

r0 = cm(1,1)/(cm(1,1)+cm(1,2)); r0(isnan(r0))=0;
p0 = cm(1,1)/(cm(1,1)+cm(2,1)); p0(isnan(p0))=0;
f10 = (2*r0*p0)/(r0+p0); f10(isnan(f10))=0;


wtPre=(s0*p0+s1*p1)/(s0+s1);
wtRec=(s0*r0+s1*r1)/(s0+s1);
wtF1=(s0*f10+s1*f11)/(s0+s1);
Acc = (cm(2,2)+cm(1,1))/sum(cm(:));
end

   