%**************************************************************************
% Matrix factorization - Kriti
%**************************************************************************
% MF with and without regularization on U and V
%**************************************************************************
function [R_est] = MF_MC_latest(y,M,sizeX,rankr, Mo)
rng(0);
R_tr=reshape( M(y,2) ,sizeX);
R = R_tr; % Observed Matrix 
lambda_U = 0.1;
lambda_V = 0.1;
X = randn(sizeX);

[F,S,T]=svd(X);
%load('svd_Xbase10m.mat');
U = F(:,1:rankr);% *S(1:rankr(1),1:rankr(1)); temp = mldivide(U1,X); [F,S,T] = lansvd(temp,rankr(2),'L');U2 = F(:,1:rankr(2))*S(1:rankr(2),1:rankr(2));V = mldivide(U2,temp);
V = S(1:rankr,1:rankr)*T(:,1:rankr)';

%X=U*V;
x=X(:);
MA=0;
min=10;
cost=[];
alpha =1;
outsweep=15;
for out = 1:outsweep
out;
% x = x + (1/alpha)*M(y - M(x,1),2);
% X = reshape(x,sizeX);

% K = R_tr - (R_tr.*X); % when mask is same as Y - wrong formulation
K = R_tr - (Mo.*X);% Y - X.*R (when mask and Y are different)
X = X+K;

 U = mrdivide(X, V); 
%  U = X*V'*pinv(V*V' + (lambda_U*eye(rankr))); % with regularization
%  U(U<0)=0.0001; % NMF

 V = mldivide(U,X);   
%  V = pinv(U'*U + (lambda_V*eye(size(rankr))))*U'*X; % with regularization
%  V(V<0)=0.0001;% NMF

X = U*V;
x = X(:);
        
a1 = norm(R_tr - R_tr.*(U*V),"fro")^2;
a3 =  lambda_U*(norm(U, "fro")^2);
a4 =  lambda_V*(norm(V, "fro")^2);
CF =a1+a3+a4;
% % CF =a3;
arr(out) = CF;  
R_est = U*V;
R_est = R_est - diag(diag(R_est));
R_est(R_est>1.0)=1.0;
R_est(R_est<0.0)=0.0;   
end

figure(1)
plot(real(arr))
ylabel('Loss Function')
xlabel('Iterations')
hFig =figure(1);
set(hFig, 'Position', [100 100 500*1 250*1])
end

