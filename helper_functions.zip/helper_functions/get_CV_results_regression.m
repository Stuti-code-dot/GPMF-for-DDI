function [ auc,aupr,r_sq,corr,p_val] = get_CV_results_regression(Y,n,cv_setting,predictionMethod  )

global Sd Sv 

AUCs  = zeros(1,n);  AUPRs = zeros(1,n);  R_sqs  = zeros(1,n);  corr_coefs  = zeros(1,n);  p_vals  = zeros(1,n);
pred_means= zeros(1,n); pred_stds= zeros(1,n); true_means= zeros(1,n);true_stds=zeros(1,n);
% loop over the n folds

for i=1:n
%     i
    [test_ind,len]=get_test_ind( cv_setting,i,n, Y,Sd,Sv);

    y2 = Y;
    y2(test_ind) = 0;
    %                i,test_ind, len
    fprintf('*');
    st=tic;
    n_num = i;
    y3=alg_template(y2,predictionMethod,test_ind ,[]);
    %     y3
%     y3
    endt= double(toc-st);
%     y3(test_ind),Y(test_ind)
    [AUCs(i)]  = calculate_auc (y3(test_ind),Y(test_ind));
    [AUPRs(i)] = calculate_aupr(y3(test_ind),Y(test_ind));
%     [pred_means(i),pred_stds(i),true_means(i),true_stds(i)]= calculate_mean_std(y3(test_ind),Y(test_ind));
    [R_sqs(i),corr_coefs(i), p_vals(i)]=calculate_regression_params_alt(y3(test_ind),Y(test_ind));
    %if (length(test_ind)==(round(len/n)-1)) %for 1st fold test_ind has 1 less element than the total elements in test_ind from other 9 folds..so copy 1 ele to X coordinate and Y coordinate
       %disp('Ìn ifffff')
    %end

end
%             AUCs,AUPRs
auc= mean(AUCs);    aupr= mean(AUPRs); r_sq = mean(R_sqs);  corr = mean(corr_coefs); p_val = mean(p_vals);

end

