function [mean_pred,std_pred,mean_true,std_true] = calculate_mean_std(predictionScores,labels)
%https://www.investopedia.com/terms/r/residual-standard-deviation.asp

sum_pred = sum(predictionScores,'all');
[r,c] = size(predictionScores);
mean_pred = sum_pred/r;
pred_mean_sub = predictionScores - mean_pred;
pred_mean_sub_sq = pred_mean_sub.^2;
sum_pred_mean_sq = sum(pred_mean_sub_sq,'all');
std_pred = sum_pred_mean_sq/(r-1);

sum_true = sum(labels,'all');
[r1,c1] = size(labels);
mean_true = sum_true/r1;
true_mean_sub = labels - mean_true;
true_mean_sub_sq = true_mean_sub.^2;
sum_true_mean_sq = sum(true_mean_sub_sq,'all');
std_true = sum_true_mean_sq/(r1-1);
% C1 = C - mean;
% Var = (C1.^2)/r;
% Std = Var.^0.5;
% length(labels);
% for i=1:length(labels)
%     percent(i) = (labels(i)-predictionScores(i))/labels(i);
%     
% end

% sum_percent = (sum(percent,'all'))/length(labels);
% sum_percent
% Std = sqrt(sum_percent/100);

    
    