for i=[1:1:10]
    disp(i)
    
end    