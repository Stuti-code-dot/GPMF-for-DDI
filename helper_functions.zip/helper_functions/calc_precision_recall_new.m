function [ FinalavgPre,FinalavgRec,FinalavgF1 ] = calc_precision_recall_new(Y,n,cv_setting,predictionMethod,knum)


avgPre=0;
avgRec=0;
avgF1=0;
p=[];r=[]; f=[];

nou=size(Y,2);
for i=1:nou
% for i=1
    getParameters(predictionMethod,cv_setting);
    [auc,aupr,y3] = get_CV_results_setting4(Y,i,cv_setting,predictionMethod);
%     y3
    x = [min(y3,[],1);max(y3,[],1)];
    b = bsxfun(@minus,y3,x(1,:));
    y3_norm = bsxfun(@rdivide,b,diff(x,1,1));

    knum=5;
        ypred=y3_norm(:,i);
        ypred(isinf(ypred)|isnan(ypred)) = 0;
%         ypred,size(ypred),i

        [sortedVlues,sortIndex] = sort(ypred,'descend');
        ind = sortIndex(1:knum);
%         sortedValues,sortIndex,ind 
         

        for j=1:size(Y,1)
            if ypred(j,1)<=0.1
            ypred(j,1) = 0;
            end
            if ypred(j,1)>0.1
            ypred(j,1) = 1;
            end
        end
        ypred(ind) = 1;
%         ypred
          
        [c,cm,ind,per] = confusion(Y(:,i)',ypred'); 
%         cm
%         i,cm
%         size((Y(:,i))'),(((ypred))')
        recall =  cm(2,2) / (sum(cm(2,:)));
        precision =  cm(2,2) / sum(cm(:,2));
        
        precision(isnan(precision))=0;
        recall(isnan(recall))=0;
        
        f1score = (2*precision*recall)/(precision+recall);
        f1score(isnan(f1score))=0;
        
        avgPre=avgPre+ precision;
        avgRec=avgRec+ recall;
        avgF1=avgF1+f1score;
      
end
% knum
FinalavgPre=avgPre/nou; p=[p,avgPre];
FinalavgRec=avgRec/nou; r=[r,avgRec];
FinalavgF1=avgF1/nou;  f=[f,avgF1];

end

   