function getParameters(classifier,cv_setting)
%
% This function retrieves optimal parameter values based on the supplied
% algorithm, the CV scenario used and the dataset on which prediction will
% be performed.
%
% INPUT:
%  classifier:  algorithm to be used
%  cv_setting:          
%
% OUTPUT:
%  params:   optimal parameter values for given inputs


global k alpha  k1 k2 k3 k4 pp lamda mu1 mu2 nu1 nu2 mu sigma gama theta1 theta2 method
global num_iter p lambda_l lambda_d lambda_t lambda_U lambda_V lambda_r scale_param lambda_U1 lambda_U3 lambda_U4
global vartheta

    switch classifier

    case 'GPMF_1layer'
        switch cv_setting 
            case 1     
                pp=2; k=23; lambda_U = 0.01; lambda_r = 1;sigma = 1; scale_param = 0.001; theta1 = 1;
            case 2
                pp=2; k=13; lambda_U = 0.5; lambda_r = 1; sigma = 1; scale_param = 0.001; theta1 = 1;
            case 3
                pp=2; k=20; lambda_U = 0.01;lambda_r = 1; sigma = 1; scale_param = 0.001; theta1 = 1;
            case 4                
                pp=2; k=8; lambda_U= 0.1; lambda_r = 1;sigma = 1; scale_param = 0.0001; theta1 = 1; %CV SETTING 2
            case 5
                pp=2; k=20; lambda_U = 0.5; lambda_r = 1; sigma = 1; scale_param = 0.001; theta1 = 1;%lambda_U = 0.5
            case 6
                pp=2; k=100; lambda_U = 0.01; lambda_r = 0.1; sigma = 0.001; scale_param = 0.1; theta1 = 0.01;
            case 7
                pp=5; k=100; lambda_U = 0.01; lambda_r = 0.5; sigma = 0.001; scale_param = 0.1; theta1 = 0.1;
            case 8
                pp=2; k=300; lambda_U = 0.5; lambda_r = 1; sigma = 0.01; scale_param = 0.01; theta1 =1;
            case 81
                pp=2; k=20; lambda_U = 0.5; lambda_r = 1; sigma = 0.01; scale_param = 0.01; theta1 = 0.1;
            case 9 % Modified code with inner loop for gamma_U
                 pp=2; k=20; lambda_U = 0; lambda_r = 0.55; sigma = 1; scale_param = 0.001; theta1 = 1;
            case 10 % Modified code with inner loop for gamma_U
                 pp=2; k=20; lambda_U = 0; lambda_r = 0.5; sigma = 1; scale_param = 0.001; theta1 = 1;
            case 11 % Modified code with inner loop for gamma_U and X train
                 pp=2; k=20; lambda_U = 0.5; lambda_r = 1; sigma = 0.01; scale_param = 0.01; theta1 = 0.1;
        end
        fprintf('pp=%g, k=%g, lambda_U=%g, lambda_r=%g, sigma=%g, scale_param =%g, theta1 =%g\n', pp, k, lambda_U, lambda_r, sigma, scale_param, theta1)
  
    case 'MF_MC_latest'%MF_1layer'
        switch cv_setting 
            case 5
                pp=2; k=20; lambda_U = 0; lambda_r = 1; sigma = 1; scale_param = 0.001; theta1 = 1;% AUPR = 0.53, AUC =0.96
            case 1
                pp=2; k=50; lambda_U = 0; lambda_r = 0.1; sigma = 1; scale_param = 0.001; theta1 = 1;%lambda_U = 0.5
  
        end
        fprintf('pp=%g, k=%g, lambda_U=%g, lambda_r=%g, sigma=%g, scale_param =%g, theta1 =%g\n', pp, k, lambda_U, lambda_r, sigma, scale_param, theta1)  
        
   
    case 'GPMF_2layer'
        switch cv_setting 
            case 1  
                pp=2; k1=23; k2 = 15;  lambda_U1 = 0.01; lambda_U3 = 0.01;lambda_r = 1;sigma = 1; scale_param = 0.001; theta1 = 1; theta2 = 1;
            case 2
                pp=2; k1=23; k2 = 15;  lambda_U1 = 0.01; lambda_U3 = 0.01;lambda_r = 1;sigma = 1; scale_param = 0.001; theta1 = 1; theta2 = 1;
            case 3
                pp=2; k1=23; k2 = 15;  lambda_U1 = 0.01; lambda_U3 = 0.01;lambda_r = 1;sigma = 1; scale_param = 0.001; theta1 = 1; theta2 = 1;
            case 4  
                pp=2; k1=23; k2 = 15;  lambda_U1 = 0.01; lambda_U3 = 0.01;lambda_r = 1;sigma = 1; scale_param = 0.001; theta1 = 1; theta2 = 1;
        end

    case 'GPMF_3layer'
        switch cv_setting 
            case 1   
                pp=2; k1=23; k2 = 15;k3 = 10;  lambda_U1 = 0.01; lambda_U4 = 0.01;lambda_r = 1;sigma = 1; scale_param = 0.001; theta1 = 1; theta2 = 1;
            case 2
                pp=2; k1=23; k2 = 15;k3 = 10;  lambda_U1 = 0.01; lambda_U4 = 0.01;lambda_r = 1;sigma = 1; scale_param = 0.001; theta1 = 1; theta2 = 1;
            case 3
                pp=2; k1=23; k2 = 15;k3 = 10;  lambda_U1 = 0.01; lambda_U4 = 0.01;lambda_r = 1;sigma = 1; scale_param = 0.001; theta1 = 1; theta2 = 1;

            case 4                
                pp=2; k1=23; k2 = 15;k3 = 10;  lambda_U1 = 0.01; lambda_U4 = 0.01;lambda_r = 1;sigma = 1; scale_param = 0.001; theta1 = 1; theta2 = 1;
        end


    case 'grdmf_2layer'
        switch cv_setting 
            case 1                            
                pp=2; alpha=0.05; mu=100; k1=17; k2=15; vartheta=1;
            case 2              
                pp=2; alpha=0.01; mu=50; k1=20; k2=15; vartheta=10; 
            case 3
                pp=5; alpha=0.1; mu=10; k1=17; k2=10; vartheta=2;              
            case 4  %copied cv2 parameters since we hide 10% viruses in cv2                
                pp=2; alpha=0.01; mu=50; k1=20; k2=15; vartheta=10; 
        end
                   
                       
    case 'grdmf_3layer'
        switch cv_setting 
            case 1
                pp=5; alpha=1; mu=5; k1=23; k2=10;k3=7; vartheta=1;
            case 2
                pp=5; alpha=1; mu=0.01; k1=20; k2=15; k3=10; vartheta=1; 
            case 3
                pp=5; alpha=1.5; mu=5; k1=23; k2=10; k3=7; vartheta=2;

            case 4               
                pp=5; alpha=1; mu=0.01; k1=20; k2=15; k3=10; vartheta=1; 
        end
          
    case 'grmf'
          
        num_iter = 1;
        k = 50;%2;%14;
        switch(cv_setting)

            case 1
%                 p=2; lambda_l = 0.0313; lambda_d = 0.01;lambda_t = 0.01; 
                p=2; lambda_l = 0.05; lambda_d = 0.3;lambda_t = 0.3; 
            case 2
            % old data optimal para:dnt chng to keep corona rsult p=3; lambda_l = 0.125; lambda_d = 0.3;lambda_t = 0.1; 
                p=2; lambda_l = 0.0625; lambda_d = 0.3;lambda_t = 0.05; %1 extra drug predicted in grmf
            case 3
            %p=7 ;lambda_l =0.25; lambda_d =0.25;lambda_t =0.01; 
                p=2 ;lambda_l =0.01; lambda_d =1.65;lambda_t =0.000001; 
            case 4
                p=2; lambda_l = 0.0625; lambda_d = 0.3;lambda_t = 0.05;
        end
                                   
                                   
    case 'gr1bmc_ppxa'
           
        switch cv_setting 
            case 1
                pp=2;lamda=0.1;mu1=0.24;mu2=0.1;
            case 2
                pp=2;lamda=0.05;mu1=1;mu2=0.5;
            case 3
                pp=2;lamda=2;mu1=0.5;mu2=0.5;
            case 4
                pp=2;lamda=0.05;mu1=1;mu2=0.5;
        end
        
    case 'ppxa'
           
        switch cv_setting 
            case 1
                pp=2;lamda=0.1;mu1=0.24;mu2=0.1;
        end

    case 'mgrnnm'
           
        switch cv_setting 
            case 1
%                 pp=2;lamda=0.1;mu1=0.24;mu2=0.1; method = 'NNM'; nu1=0.5;nu2=0.5;
                pp=2;lamda=0.1;mu1=0.5;mu2=0.5; method = 'NNM'; nu1=0.5;nu2=0.5;
            case 2
                pp=2;lamda=0.05;mu1=1;mu2=0.5;
            case 3
                pp=2;lamda=2;mu1=0.5;mu2=0.5;
            case 4
                pp=2;lamda=0.05;mu1=1;mu2=0.5;
        end
            
    case 'grmc_admm'
        switch cv_setting 
            case 1
                pp=2;lamda=0.01;mu1=0.01;mu2=0.023;
            case 2
                pp=2;lamda=0.01;mu1=0.01;mu2=0.01;
            case 3
                pp=2;lamda=0.01;mu1=0.1;mu2=0.7;
            case 4
                pp=2;lamda=0.01;mu1=0.05;mu2=0.01;
        end
    end
    