function x = Proxfunc(y,delta,tau)

%min_x 1/2 (x_y)^2 -tau*log(|x|+delta)

xtemp = [0];

%positive x
D = (delta+y)^2 + 4*tau;
x1 = (y-delta - sqrt(D))/2;
x2 = (y-delta + sqrt(D))/2;
[i1,i2] = size(y);

for i=1:i1
    for j=1:i2
        if x1(i,j) > 0
            xtemp = [xtemp x1(i,j)];
        end
        if x2(i,j) > 0
            xtemp = [xtemp x2(i,j)];
        end
    end
end

%negative x
D_ = (y-delta)^2 - 4*tau;
x3 = (y+delta - sqrt(D_))/2;
x4 = (y+delta + sqrt(D_))/2;

for i=1:i1
    for j=1:i2
        if x3(i,j) < 0 && isreal(x3(i,j))
            xtemp = [xtemp x3(i,j)];
        end
  
        if x4(i,j) < 0 && isreal(x4(i,j))
            xtemp = [xtemp x4(i,j)];
        end
    end
end

% xtemp

y_new = reshape(y.',1,[]);
delta_new = reshape(delta.',1,[]);

ftemp = 1/2.*(xtemp-y_new).^2 - tau*log(abs(xtemp)+delta_new);

[~,idx] = min(ftmp);
x = xtemp(idx);
% x
end
